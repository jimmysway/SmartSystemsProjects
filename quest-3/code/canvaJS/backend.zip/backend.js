const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const fs = require('fs');
const Papa = require('papaparse');

const app = express();
const server = http.createServer(app);
const io = socketIo(server);

app.use(express.static(__dirname));  // Serve static files

function getLastDataFromCSV(filePath) {
    const csvContent = fs.readFileSync(filePath, 'utf-8');
    const parsed = Papa.parse(csvContent, { header: true });
    return parsed.data[parsed.data.length - 2];
}

const csvFilePath = './stocks-csv.csv';
function timeStringToDate(timeStr) {
    const [hours, minutes, seconds] = timeStr.split(":").map(Number);
    const date = new Date();
    date.setHours(hours, minutes, seconds, 0);
    return date;
}

fs.watch(csvFilePath, (eventType, filename) => {
    if (eventType === 'change') {
        const newEntry = getLastDataFromCSV(csvFilePath);
        
        // Parse the string to get a Date object
        const parsedTime = timeStringToDate(newEntry.Time);
        
        io.emit('data', {
            x: parsedTime,
            y: parseFloat(newEntry.Step)
        });
    }
});

server.listen(3000, () => {
    console.log('listening on *:3000');
});
